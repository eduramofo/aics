<#
.SYNOPSIS
AICS - Automatic Internet Connection Sharing Service

.DESCRIPTION
Este script configura automaticamente o compartilhamento de internet (ICS)
no Windows de forma dinâmica e resiliente.

FUNCIONALIDADES:
- Detecta automaticamente a interface com internet (rota padrão)
- Lê a interface privada via arquivo de configuração local
- Evita reconfiguração desnecessária (idempotente)
- Configura ICS via COM (HNetCfg.HNetShare)
- Configura IP fixo na rede interna
- Funciona em modo serviço (NSSM)

CONFIGURAÇÃO:
Editar o arquivo config.txt na mesma pasta:

interface=Ethernet 2
private_ip=10.10.10.1

REQUISITOS:
- Executar como Administrador
- Serviço ICS (SharedAccess) habilitado no Windows
#>

# =========================
# CONFIG BASE
# =========================
$BasePath               = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $BasePath) { $BasePath = "C:\AICS" }
$PrefixLength           = 24
$TimeoutPrivateSeconds  = 30
$TimeoutPublicSeconds   = 30
$LogFile                = "$BasePath\log.txt"

# =========================
# LOG
# =========================
function Write-Log {
    param ([string]$Message, [string]$Level = "INFO")
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$Level] $Message"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

# =========================
# LÊ CONFIG
# =========================
$PrivateInterface = "Ethernet 2"
$PrivateIP        = "10.10.10.1"

$configPath = "$BasePath\config.txt"
if (Test-Path $configPath) {
    foreach ($line in Get-Content $configPath) {
        if ($line -match "^interface=(.+)$")  { $PrivateInterface = $Matches[1].Trim() }
        if ($line -match "^private_ip=(.+)$") { $PrivateIP        = $Matches[1].Trim() }
    }
} else {
    Write-Log "config.txt não encontrado. Usando valores padrão (interface='$PrivateInterface', ip='$PrivateIP')." "AVISO"
}

# =========================
# FUNÇÕES
# =========================

function Wait-InterfaceUp {
    param (
        [string]$InterfaceAlias,
        [int]$TimeoutSeconds = 30
    )

    $i = 0
    while ($i -lt $TimeoutSeconds) {
        $iface = Get-NetAdapter -Name $InterfaceAlias -ErrorAction SilentlyContinue
        if ($iface -and $iface.Status -eq "Up") {
            return $true
        }

        Start-Sleep 1
        $i++
    }

    return $false
}

function Get-PublicInterface {
    param (
        [string]$PrivateInterface
    )

    $routes = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue |
        Sort-Object RouteMetric, InterfaceMetric

    if (-not $routes) { return $null }

    foreach ($route in $routes) {
        $iface = Get-NetAdapter -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue

        if (-not $iface) { continue }
        if ($iface.Status -ne "Up") { continue }
        if ($iface.Name -eq $PrivateInterface) { continue }

        return $iface.Name
    }

    return $null
}

# =========================
# ESPERA REDE PRIVADA
# =========================
if (-not (Wait-InterfaceUp -InterfaceAlias $PrivateInterface -TimeoutSeconds $TimeoutPrivateSeconds)) {
    Write-Log "Interface privada '$PrivateInterface' não ficou disponível em ${TimeoutPrivateSeconds}s." "ERRO"
    exit 1
}

# =========================
# DETECTA INTERFACE PÚBLICA
# =========================
$PublicInterface = $null
$i = 0

while (-not $PublicInterface -and $i -lt $TimeoutPublicSeconds) {
    $PublicInterface = Get-PublicInterface -PrivateInterface $PrivateInterface

    if (-not $PublicInterface) {
        Start-Sleep 1
        $i++
    }
}

if (-not $PublicInterface) {
    Write-Log "Não foi possível detectar interface com internet em ${TimeoutPublicSeconds}s." "ERRO"
    exit 1
}

# =========================
# MAPEAMENTO ICS (COM OBJECT)
# =========================
$netShare = New-Object -ComObject HNetCfg.HNetShare
$map = @{}

foreach ($conn in $netShare.EnumEveryConnection()) {
    $props = $netShare.NetConnectionProps($conn)
    $map[$props.Name] = $conn
}

if (-not $map.ContainsKey($PublicInterface) -or -not $map.ContainsKey($PrivateInterface)) {
    Write-Log "Interfaces não encontradas no sistema ICS (pub='$PublicInterface', priv='$PrivateInterface')." "ERRO"
    exit 1
}

$pub  = $map[$PublicInterface]
$priv = $map[$PrivateInterface]

$cfgPub  = $netShare.INetSharingConfigurationForINetConnection($pub)
$cfgPriv = $netShare.INetSharingConfigurationForINetConnection($priv)

# =========================
# VERIFICA SE PRECISA ALTERAR (IDEMPOTENTE)
# =========================
$needsChange = $false

if (-not $cfgPub.SharingEnabled -or $cfgPub.SharingConnectionType -ne 0) {
    $needsChange = $true
}

if (-not $cfgPriv.SharingEnabled -or $cfgPriv.SharingConnectionType -ne 1) {
    $needsChange = $true
}

# =========================
# APLICA ICS SE NECESSÁRIO
# =========================
function Apply-NetworkConfig {
    param ([string]$PubIface, [string]$PrivIface)

    # Forwarding em ambas as interfaces
    Get-NetIPInterface | Where-Object { $_.InterfaceAlias -eq $PubIface -or $_.InterfaceAlias -eq $PrivIface } |
        Set-NetIPInterface -Forwarding Enabled -ErrorAction SilentlyContinue

    Set-NetIPInterface -InterfaceAlias $PubIface  -WeakHostSend    Enabled -ErrorAction SilentlyContinue
    Set-NetIPInterface -InterfaceAlias $PubIface  -WeakHostReceive Enabled -ErrorAction SilentlyContinue
    Set-NetIPInterface -InterfaceAlias $PrivIface -WeakHostSend    Enabled -ErrorAction SilentlyContinue
    Set-NetIPInterface -InterfaceAlias $PrivIface -WeakHostReceive Enabled -ErrorAction SilentlyContinue

    # Confirma o que foi aplicado
    $pub  = Get-NetIPInterface -InterfaceAlias $PubIface  -AddressFamily IPv4 -ErrorAction SilentlyContinue
    $priv = Get-NetIPInterface -InterfaceAlias $PrivIface -AddressFamily IPv4 -ErrorAction SilentlyContinue
    Write-Log "NetworkConfig $PubIface  -> Forwarding=$($pub.Forwarding) WeakHostSend=$($pub.WeakHostSend) WeakHostReceive=$($pub.WeakHostReceive)"
    Write-Log "NetworkConfig $PrivIface -> Forwarding=$($priv.Forwarding) WeakHostSend=$($priv.WeakHostSend) WeakHostReceive=$($priv.WeakHostReceive)"
}

if ($needsChange) {
    $cfgPub.DisableSharing()
    $cfgPriv.DisableSharing()

    $cfgPub.EnableSharing(0)   # Internet
    $cfgPriv.EnableSharing(1)  # Rede privada

    Write-Log "ICS configurado (pub='$PublicInterface', priv='$PrivateInterface')."

    # Aguarda o ICS estabilizar antes de configurar IP
    # (o ICS remove IPs da interface privada ao ser ativado)
    Start-Sleep -Seconds 3
}

# Sempre reaplica Forwarding/WeakHost (o ICS pode resetar ao ser ativado)
Apply-NetworkConfig -PubIface $PublicInterface -PrivIface $PrivateInterface

# =========================
# CONFIGURA IP FIXO (LAN)
# =========================
function Test-IPExists {
    param ([string]$InterfaceAlias, [string]$IPAddress)
    # Usa netsh como fonte de verdade independente do PolicyStore
    $out = netsh interface ipv4 show addresses name="$InterfaceAlias" 2>$null
    return ($out -match [regex]::Escape($IPAddress))
}

function Set-FixedIP {
    param ([string]$InterfaceAlias, [string]$IPAddress, [int]$PrefixLen)

    # Remove apenas se o IP específico já existir, para não brigar com o ICS
    $existing = Get-NetIPAddress -InterfaceAlias $InterfaceAlias -IPAddress $IPAddress -ErrorAction SilentlyContinue
    if ($existing) {
        Remove-NetIPAddress -InterfaceAlias $InterfaceAlias -IPAddress $IPAddress -Confirm:$false -ErrorAction SilentlyContinue
    }

    New-NetIPAddress `
        -InterfaceAlias $InterfaceAlias `
        -IPAddress $IPAddress `
        -PrefixLength $PrefixLen `
        -ErrorAction SilentlyContinue | Out-Null

    # Aguarda IP aparecer (via netsh, independente de PolicyStore/AddressState)
    $waited = 0
    while ($waited -lt 15) {
        if (Test-IPExists -InterfaceAlias $InterfaceAlias -IPAddress $IPAddress) { return $true }
        Start-Sleep 1
        $waited++
    }

    Write-Log "IP $IPAddress nao apareceu em $InterfaceAlias apos ${waited}s." "AVISO"
    return $false
}

if (Test-IPExists -InterfaceAlias $PrivateInterface -IPAddress $PrivateIP) {
    Write-Log "IP fixo ja esta presente: $PrivateIP na interface '$PrivateInterface'."
} else {
    if (Set-FixedIP -InterfaceAlias $PrivateInterface -IPAddress $PrivateIP -PrefixLen $PrefixLength) {
        Write-Log "IP fixo configurado: $PrivateIP na interface '$PrivateInterface'."
    }
}

# =========================
# LOOP DE MONITORAMENTO
# Mantém o serviço vivo e reaplica config se a rede mudar
# =========================
Write-Log "Servico ativo. Monitorando a cada 60s..."

while ($true) {
    Start-Sleep -Seconds 60

    # Reverifica interface publica
    $newPublic = Get-PublicInterface -PrivateInterface $PrivateInterface

    if (-not $newPublic) { continue }

    # Reaplica ICS se a interface publica tiver mudado
    if ($newPublic -ne $PublicInterface) {
        Write-Log "Interface publica mudou: '$PublicInterface' -> '$newPublic'. Reaplicando ICS..."
        $PublicInterface = $newPublic

        if (-not $map.ContainsKey($PublicInterface)) {
            foreach ($conn in $netShare.EnumEveryConnection()) {
                $props = $netShare.NetConnectionProps($conn)
                $map[$props.Name] = $conn
            }
        }

        if ($map.ContainsKey($PublicInterface)) {
            $pub     = $map[$PublicInterface]
            $cfgPub  = $netShare.INetSharingConfigurationForINetConnection($pub)
            $cfgPriv = $netShare.INetSharingConfigurationForINetConnection($priv)

            $cfgPub.DisableSharing()
            $cfgPriv.DisableSharing()
            $cfgPub.EnableSharing(0)
            $cfgPriv.EnableSharing(1)

            Start-Sleep -Seconds 3
            Apply-NetworkConfig -PubIface $PublicInterface -PrivIface $PrivateInterface

            Write-Log "ICS reaplicado (pub='$PublicInterface', priv='$PrivateInterface')."
        }
    }

    # Reaplica IP fixo se tiver sumido
    if (-not (Test-IPExists -InterfaceAlias $PrivateInterface -IPAddress $PrivateIP)) {
        if (Set-FixedIP -InterfaceAlias $PrivateInterface -IPAddress $PrivateIP -PrefixLen $PrefixLength) {
            Write-Log "IP fixo reaplicado: $PrivateIP na interface '$PrivateInterface'."
        }
    }
}